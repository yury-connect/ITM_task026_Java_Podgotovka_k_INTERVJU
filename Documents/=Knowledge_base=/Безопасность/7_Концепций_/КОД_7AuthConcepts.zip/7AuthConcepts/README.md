# Auth Demo: 4 способа защитить один ресурс

Учебный мини-проект на Java 21 и Spring Boot 3 показывает, как один логический ресурс `/profile` можно защитить четырьмя разными способами:

- `GET /basic/profile` через Basic Auth;
- `GET /api-key/profile` через API key;
- `GET /jwt/profile` через Bearer JWT;
- `GET /session/profile` через server-side session cookie.

Проект специально не production-ready: здесь нет базы данных, Spring Security, OAuth2 authorization server или OpenID Connect provider. Пользователи, API keys и sessions хранятся in-memory, чтобы было проще сравнить концепции.

## Как запустить

Требования:

- Java 21;
- Maven 3.9+.

```bash
mvn spring-boot:run
```

Приложение стартует на `http://localhost:8080`.

Демо-пользователь:

- username: `demo`
- password: `password`

Демо API key:

- `demo-api-key-123`

## Endpoints

| Endpoint | Что делает |
| --- | --- |
| `GET /basic/profile` | Возвращает профиль после проверки `Authorization: Basic ...` |
| `GET /api-key/profile` | Возвращает профиль после проверки `X-API-Key` |
| `POST /jwt/login` | Проверяет username/password и возвращает JWT |
| `GET /jwt/profile` | Возвращает профиль после проверки `Authorization: Bearer <jwt>` |
| `POST /session/login` | Проверяет username/password, создает session id и ставит cookie |
| `GET /session/profile` | Возвращает профиль после проверки `SESSION_ID` из cookie |
| `POST /session/logout` | Удаляет session id из storage и очищает cookie |

## Basic Auth

```bash
curl -i http://localhost:8080/basic/profile \
  -H "Authorization: Basic ZGVtbzpwYXNzd29yZA=="
```

`ZGVtbzpwYXNzd29yZA==` - это Base64 от строки `demo:password`. Base64 не шифрует данные, поэтому Basic Auth имеет смысл использовать только поверх HTTPS.

## API Key

```bash
curl -i http://localhost:8080/api-key/profile \
  -H "X-API-Key: demo-api-key-123"
```

API key - это credential. Он часто идентифицирует приложение, сервис или клиента, а не обязательно конкретного пользователя-человека.

## Bearer JWT

Сначала получаем JWT:

```bash
curl -i http://localhost:8080/jwt/login \
  -H "Content-Type: application/json" \
  -d '{"username":"demo","password":"password"}'
```

Затем передаем его в `Authorization` header:

```bash
curl -i http://localhost:8080/jwt/profile \
  -H "Authorization: Bearer <accessToken>"
```

`Bearer` - это HTTP authentication scheme для передачи токена. `JWT` - это формат токена. Поэтому Bearer JWT - это комбинация схемы передачи и формата токена.

## Session-based Authentication

Создаем session cookie:

```bash
curl -i -c cookies.txt http://localhost:8080/session/login \
  -H "Content-Type: application/json" \
  -d '{"username":"demo","password":"password"}'
```

Обращаемся к профилю с cookie:

```bash
curl -i -b cookies.txt http://localhost:8080/session/profile
```

Выходим из сессии:

```bash
curl -i -b cookies.txt -c cookies.txt -X POST http://localhost:8080/session/logout
```

При session-based authentication сервер хранит состояние сессии у себя, а клиент хранит только session id в cookie. Это отличается от stateless JWT, где сервер обычно не хранит сессию.

## Сравнение понятий

| Подход | Что это такое | Уровень | Что передается по HTTP | Что проверяет сервер | Частая ошибка |
| --- | --- | --- | --- | --- | --- |
| Basic Auth | HTTP authentication scheme | HTTP authentication scheme + credentials transport | `Authorization: Basic base64(username:password)` | username/password | Думать, что Base64 шифрует пароль |
| API Key | Credential | Credentials | Например, `X-API-Key: ...` | наличие и права ключа | Считать, что API key всегда равен пользователю-человеку |
| Bearer Token | HTTP authentication scheme | Token transport scheme | `Authorization: Bearer <token>` | валидность предъявленного токена | Называть Bearer форматом токена |
| JWT | Формат токена | Token format | Обычно внутри Bearer header | подпись, `exp`, claims | Называть JWT самостоятельным способом авторизации |
| Session-based auth | Серверная сессия | Server-side session | Cookie с session id | наличие session id в storage | Считать cookie всей сессией, хотя состояние хранит сервер |
| OAuth2 | Framework делегированной авторизации | Authorization framework | Разные запросы, коды, токены | client, grants, scopes, tokens | Называть OAuth2 просто login-протоколом |
| OpenID Connect | Identity layer поверх OAuth2 | Authentication/identity protocol | ID token, access token, redirects | identity claims, issuer, audience, signature | Путать OIDC с чистым OAuth2 |

## Почему здесь нет полноценного OAuth2 и OpenID Connect

OAuth2 - это не один endpoint и не один формат токена. Это framework с ролями, grant types, scopes, authorization server, resource server и client registration. OpenID Connect добавляет identity layer поверх OAuth2: ID token, discovery, issuer, audience, nonce и другие правила.

Этот проект показывает низкоуровневые способы предъявить credentials, token или session id к одному ресурсу. Полноценная реализация OAuth2/OIDC скрыла бы эту учебную мысль за большим количеством протокольной инфраструктуры.

## Почему JWT не стоит называть самостоятельным способом авторизации

JWT - это формат токена, а не весь auth-процесс. В реальной системе нужно отдельно объяснять:

- как пользователь прошел аутентификацию;
- кто выпустил токен;
- как токен передается по HTTP;
- что означает его payload;
- какие claims проверяет сервер;
- какие права или scopes из него следуют.

Фраза "мы используем JWT" без этих уточнений не отвечает на вопрос, какой именно authentication или authorization flow реализован.

## Готовые запросы

Файл `requests/auth-demo.http` содержит сценарии для VS Code REST Client или IntelliJ HTTP Client:

1. Basic Auth success;
2. Basic Auth fail;
3. API Key success;
4. API Key fail;
5. JWT login;
6. JWT profile success;
7. JWT profile without token;
8. Session login;
9. Session profile success;
10. Session logout;
11. Session profile after logout.
