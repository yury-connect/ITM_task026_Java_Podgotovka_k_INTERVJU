package com.example.authdemo.util;

import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;

@Component
public class BasicAuthParser {

    public Optional<Credentials> parse(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.regionMatches(true, 0, "Basic ", 0, 6)) {
            return Optional.empty();
        }

        try {
            String encodedCredentials = authorizationHeader.substring(6).trim();
            String decodedCredentials = new String(
                    Base64.getDecoder().decode(encodedCredentials),
                    StandardCharsets.UTF_8
            );
            int separatorIndex = decodedCredentials.indexOf(':');
            if (separatorIndex < 0) {
                return Optional.empty();
            }

            String username = decodedCredentials.substring(0, separatorIndex);
            String password = decodedCredentials.substring(separatorIndex + 1);
            return Optional.of(new Credentials(username, password));
        } catch (IllegalArgumentException e) {
            return Optional.empty();
        }
    }

    public record Credentials(String username, String password) {
    }
}
