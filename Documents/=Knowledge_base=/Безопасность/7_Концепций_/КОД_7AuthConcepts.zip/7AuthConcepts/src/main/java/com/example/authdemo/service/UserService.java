package com.example.authdemo.service;

import com.example.authdemo.dto.ProfileResponse;
import com.example.authdemo.model.DemoUser;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
public class UserService {

    private final Map<String, DemoUser> users = Map.of(
            "demo", new DemoUser("demo", "password", "Demo User", "demo@example.com")
    );

    public Optional<DemoUser> authenticate(String username, String password) {
        return findByUsername(username)
                .filter(user -> user.password().equals(password));
    }

    public Optional<DemoUser> findByUsername(String username) {
        if (username == null || username.isBlank()) {
            return Optional.empty();
        }

        return Optional.ofNullable(users.get(username));
    }

    public ProfileResponse profileFor(DemoUser user, String authType) {
        return new ProfileResponse(user.username(), user.displayName(), user.email(), authType);
    }
}
