package com.example.authdemo.dto;

public record ErrorResponse(
        String error,
        String message
) {
}
