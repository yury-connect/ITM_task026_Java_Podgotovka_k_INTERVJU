package com.example.authdemo.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

@Service
public class ApiKeyService {

    private final Map<String, String> apiKeys = Map.of(
            "demo-api-key-123", "demo"
    );

    public Optional<String> findUsernameByApiKey(String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            return Optional.empty();
        }

        return Optional.ofNullable(apiKeys.get(apiKey));
    }
}
