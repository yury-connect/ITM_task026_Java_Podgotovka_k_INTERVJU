package com.example.authdemo.controller;

import com.example.authdemo.dto.ErrorResponse;
import com.example.authdemo.dto.LoginRequest;
import com.example.authdemo.model.DemoSession;
import com.example.authdemo.model.DemoUser;
import com.example.authdemo.service.SessionService;
import com.example.authdemo.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/session")
public class SessionAuthController {

    private final SessionService sessionService;
    private final UserService userService;

    public SessionAuthController(SessionService sessionService, UserService userService) {
        this.sessionService = sessionService;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request, HttpServletResponse response) {
        Optional<DemoUser> user = userService.authenticate(request.username(), request.password());
        if (user.isEmpty()) {
            return unauthorized("Invalid username or password");
        }

        DemoSession session = sessionService.createSession(user.get().username());
        Cookie cookie = new Cookie(SessionService.COOKIE_NAME, session.sessionId());
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        response.addCookie(cookie);

        return ResponseEntity.ok(userService.profileFor(user.get(), "Session-based authentication"));
    }

    @GetMapping("/profile")
    public ResponseEntity<?> profile(
            @CookieValue(value = SessionService.COOKIE_NAME, required = false) String sessionId
    ) {
        // При session-based authentication сервер хранит состояние сессии у себя,
        // а клиент хранит только session id в cookie. Это отличается от stateless JWT,
        // где сервер обычно не хранит сессию.
        Optional<DemoSession> session = sessionService.findBySessionId(sessionId);
        if (session.isEmpty()) {
            return unauthorized("Missing or invalid session cookie");
        }

        return userService.findByUsername(session.get().username())
                .<ResponseEntity<?>>map(user -> ResponseEntity.ok(userService.profileFor(user, "Session-based authentication")))
                .orElseGet(() -> unauthorized("Session points to unknown demo user"));
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(
            @CookieValue(value = SessionService.COOKIE_NAME, required = false) String sessionId,
            HttpServletResponse response
    ) {
        if (sessionId != null) {
            sessionService.deleteSession(sessionId);
        }

        Cookie cookie = new Cookie(SessionService.COOKIE_NAME, "");
        cookie.setHttpOnly(true);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        return ResponseEntity.noContent().build();
    }

    private ResponseEntity<ErrorResponse> unauthorized(String message) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new ErrorResponse("unauthorized", message));
    }
}
