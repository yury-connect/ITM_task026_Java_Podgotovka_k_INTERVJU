package com.example.authdemo.controller;

import com.example.authdemo.dto.ErrorResponse;
import com.example.authdemo.model.DemoUser;
import com.example.authdemo.service.UserService;
import com.example.authdemo.util.BasicAuthParser;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/basic")
public class BasicAuthController {

    private final BasicAuthParser basicAuthParser;
    private final UserService userService;

    public BasicAuthController(BasicAuthParser basicAuthParser, UserService userService) {
        this.basicAuthParser = basicAuthParser;
        this.userService = userService;
    }

    @GetMapping("/profile")
    public ResponseEntity<?> profile(
            @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorizationHeader
    ) {
        // Basic Auth — это HTTP authentication scheme, при которой credentials передаются в Authorization header.
        // Base64 — это не шифрование, поэтому в реальном мире нужен HTTPS.
        Optional<BasicAuthParser.Credentials> credentials = basicAuthParser.parse(authorizationHeader);
        if (credentials.isEmpty()) {
            return unauthorized("Missing or invalid Basic Authorization header");
        }

        return userService.authenticate(credentials.get().username(), credentials.get().password())
                .<ResponseEntity<?>>map(user -> ResponseEntity.ok(userService.profileFor(user, "Basic Auth")))
                .orElseGet(() -> unauthorized("Invalid username or password"));
    }

    private ResponseEntity<ErrorResponse> unauthorized(String message) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new ErrorResponse("unauthorized", message));
    }
}
