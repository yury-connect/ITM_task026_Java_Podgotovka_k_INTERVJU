package com.example.authdemo.dto;

public record ProfileResponse(
        String username,
        String displayName,
        String email,
        String authType
) {
}
