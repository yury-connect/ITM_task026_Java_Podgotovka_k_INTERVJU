package com.example.authdemo.model;

public record DemoUser(
        String username,
        String password,
        String displayName,
        String email
) {
}
