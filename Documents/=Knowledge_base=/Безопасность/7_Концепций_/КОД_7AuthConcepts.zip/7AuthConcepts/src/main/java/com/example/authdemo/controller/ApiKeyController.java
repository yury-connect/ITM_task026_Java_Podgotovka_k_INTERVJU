package com.example.authdemo.controller;

import com.example.authdemo.dto.ErrorResponse;
import com.example.authdemo.model.DemoUser;
import com.example.authdemo.service.ApiKeyService;
import com.example.authdemo.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/api-key")
public class ApiKeyController {

    private final ApiKeyService apiKeyService;
    private final UserService userService;

    public ApiKeyController(ApiKeyService apiKeyService, UserService userService) {
        this.apiKeyService = apiKeyService;
        this.userService = userService;
    }

    @GetMapping("/profile")
    public ResponseEntity<?> profile(
            @RequestHeader(value = "X-API-Key", required = false) String apiKey
    ) {
        // API key — это credential. Он часто идентифицирует приложение, сервис или клиента,
        // а не обязательно конкретного пользователя-человека.
        if (apiKey == null || apiKey.isBlank()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new ErrorResponse("unauthorized", "Missing X-API-Key header"));
        }

        Optional<String> username = apiKeyService.findUsernameByApiKey(apiKey);
        if (username.isEmpty()) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN)
                    .body(new ErrorResponse("forbidden", "Invalid API key"));
        }

        DemoUser user = userService.findByUsername(username.get())
                .orElseThrow(() -> new IllegalStateException("API key points to unknown demo user"));
        return ResponseEntity.ok(userService.profileFor(user, "API Key"));
    }
}
