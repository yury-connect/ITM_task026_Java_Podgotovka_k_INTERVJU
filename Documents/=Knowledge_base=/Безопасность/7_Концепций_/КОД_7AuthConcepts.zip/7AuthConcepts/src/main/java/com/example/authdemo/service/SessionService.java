package com.example.authdemo.service;

import com.example.authdemo.model.DemoSession;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class SessionService {

    public static final String COOKIE_NAME = "SESSION_ID";

    private final Map<String, DemoSession> sessions = new ConcurrentHashMap<>();

    public DemoSession createSession(String username) {
        String sessionId = UUID.randomUUID().toString();
        DemoSession session = new DemoSession(sessionId, username, Instant.now());
        sessions.put(sessionId, session);
        return session;
    }

    public Optional<DemoSession> findBySessionId(String sessionId) {
        if (sessionId == null || sessionId.isBlank()) {
            return Optional.empty();
        }

        return Optional.ofNullable(sessions.get(sessionId));
    }

    public void deleteSession(String sessionId) {
        if (sessionId != null) {
            sessions.remove(sessionId);
        }
    }
}
