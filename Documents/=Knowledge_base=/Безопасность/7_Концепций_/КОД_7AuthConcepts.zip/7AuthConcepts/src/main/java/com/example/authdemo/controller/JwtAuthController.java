package com.example.authdemo.controller;

import com.example.authdemo.dto.ErrorResponse;
import com.example.authdemo.dto.LoginRequest;
import com.example.authdemo.dto.LoginResponse;
import com.example.authdemo.model.DemoUser;
import com.example.authdemo.service.JwtService;
import com.example.authdemo.service.UserService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/jwt")
public class JwtAuthController {

    private final JwtService jwtService;
    private final UserService userService;

    public JwtAuthController(JwtService jwtService, UserService userService) {
        this.jwtService = jwtService;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        Optional<DemoUser> user = userService.authenticate(request.username(), request.password());
        if (user.isEmpty()) {
            return unauthorized("Invalid username or password");
        }

        String accessToken = jwtService.createAccessToken(user.get());
        return ResponseEntity.ok(new LoginResponse(accessToken, "Bearer"));
    }

    @GetMapping("/profile")
    public ResponseEntity<?> profile(
            @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authorizationHeader
    ) {
        // Bearer — это схема передачи токена в HTTP Authorization header. JWT — это формат токена.
        // Поэтому Bearer JWT — это комбинация схемы передачи и формата токена.
        Optional<String> token = extractBearerToken(authorizationHeader);
        if (token.isEmpty()) {
            return unauthorized("Missing or invalid Bearer token");
        }

        Optional<String> username = jwtService.validateAndExtractUsername(token.get());
        if (username.isEmpty()) {
            return unauthorized("JWT signature or expiration is invalid");
        }

        return userService.findByUsername(username.get())
                .<ResponseEntity<?>>map(user -> ResponseEntity.ok(userService.profileFor(user, "Bearer JWT")))
                .orElseGet(() -> unauthorized("JWT subject does not match a known user"));
    }

    private Optional<String> extractBearerToken(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.regionMatches(true, 0, "Bearer ", 0, 7)) {
            return Optional.empty();
        }

        String token = authorizationHeader.substring(7).trim();
        return token.isBlank() ? Optional.empty() : Optional.of(token);
    }

    private ResponseEntity<ErrorResponse> unauthorized(String message) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(new ErrorResponse("unauthorized", message));
    }
}
