package com.example.authdemo.dto;

public record LoginResponse(
        String accessToken,
        String tokenType
) {
}
