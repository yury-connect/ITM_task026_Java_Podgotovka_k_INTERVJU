package com.example.authdemo.model;

import java.time.Instant;

public record DemoSession(
        String sessionId,
        String username,
        Instant createdAt
) {
}
