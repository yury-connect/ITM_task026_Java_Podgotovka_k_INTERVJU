# Сущности

JPA-сущности: Card, User, Role и другие.
