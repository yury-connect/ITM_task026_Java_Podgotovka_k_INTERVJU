# Ресурсы

application.yml, настройки логов, конфигурации Liquibase и прочее.
